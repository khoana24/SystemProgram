# BÁO CÁO: COPYFLOW — FILE & FOLDER COPY

**Học phần:** Lập trình hệ thống — File Input/Output  
**Ngôn ngữ và môi trường:** C11, POSIX, Lubuntu/Linux  
**Tên đề tài:** Write a C program to demonstrate file and folder copy

## 1. Giới thiệu và mục tiêu

Sao chép dữ liệu là thao tác cơ bản trong hệ điều hành. Tuy nhiên, việc đọc một khối rồi gọi write một lần chưa đủ bảo đảm sao chép đúng, vì hệ điều hành có thể chỉ xử lý một phần số byte yêu cầu hoặc trả lỗi do signal, quyền truy cập và dung lượng lưu trữ.

CopyFlow mô phỏng một công cụ sao chép file và thư mục. Trọng tâm là xử lý nội dung ở mức byte bằng open, read, write và close. Chương trình bổ sung menu Terminal, thanh tiến trình từng file, lựa chọn ghi đè hoặc bỏ qua, kiểm tra sau sao chép và thống kê tác vụ để thuận tiện demo trước lớp.

## 2. Yêu cầu chức năng

| Nhóm | Chức năng |
|---|---|
| Dữ liệu file | Copy văn bản/nhị phân, buffer 4096 byte, partial I/O và EINTR |
| Thư mục | Đệ quy nhiều cấp, folder rỗng, merge vào đích đã có |
| Xử lý trùng tên | Ghi đè regular file hoặc bỏ qua mục đích tồn tại |
| Xem trước | Dry-run liệt kê kế hoạch, không tạo hoặc ghi đè đích |
| Metadata cơ bản | Preserve quyền rwx và atime/mtime file/folder |
| Kiểm chứng | So sánh byte nguồn/đích sau khi chép nếu bật verify |
| Tiện ích | Tạo mẫu tự động; so sánh file độc lập; glob loại trừ file/folder |
| Liên kết | Giữ symlink, không theo khi duyệt; bảo vệ cùng inode |
| Giao diện | Menu, ANSI, prompt, progress file, thống kê |
| Điều khiển | CLI tùy chọn, Ctrl+C, mã thoát và lỗi rõ |

Đích được hiểu là đường dẫn chính xác. Ví dụ source/a.txt được chép thành backup/a.txt khi đích là backup. Chương trình không tự thêm source thành một cấp thư mục mới.

## 3. Thiết kế module

- copy_file.h/c: sao chép và so sánh dữ liệu byte; cung cấp copy_file và copy_file_ex.
- copy_tree.h/c: kiểm tra đường dẫn, duyệt thư mục, tạo cây đích, xử lý symlink, cập nhật bộ đếm.
- app_support.h/c: tạo dữ liệu mẫu bằng POSIX và diễn giải lỗi tiếng Việt.
- main.c: menu, tham số CLI, giao diện, thời gian, tốc độ, SIGINT.
- tests: kiểm thử dữ liệu, cây thư mục, giao diện và lỗi giả lập.

copy_file giữ chữ ký đơn giản đúng yêu cầu ban đầu. copy_file_ex nhận thêm cấu hình verify, cờ hủy và callback tiến trình. Vì vậy phần dữ liệu không cần tự in màu hay menu, có thể tái sử dụng ở chương trình khác.

## 4. Thuật toán sao chép file

```text
COPY_FILE(src, dest)
    Kiểm tra tham số
    Mở nguồn, kiểm tra regular file
    Kiểm tra đích không trùng inode/device của nguồn
    Từ chối symlink đích
    Mở đích với O_WRONLY | O_CREAT | O_TRUNC
    Lặp đến EOF:
        Kiểm tra yêu cầu hủy
        Đọc tối đa 4096 byte
        EINTR: thử lại; lỗi khác: cleanup
        Nếu đọc 0 byte: kết thúc
        offset = 0
        Trong khi offset < số byte đã đọc:
            Ghi từ buffer + offset, số lượng = count - offset
            EINTR: thử lại; lỗi khác hoặc 0 byte: cleanup
            offset += số byte thực tế đã ghi
        Cập nhật tiến trình
    Nếu bật verify: so sánh lại từng byte
    Nếu bật preserve: đặt rwx và atime/mtime của đích theo nguồn
    Đóng cả hai file, kiểm tra lỗi đóng
    Trả 0 nếu hoàn tất; -1 và errno nếu lỗi
```

Buffer dùng unsigned char. Chương trình không dùng strlen, vì byte 0 có thể nằm giữa file nhị phân. Không cần xóa buffer trước mỗi vòng vì chỉ ghi vùng dữ liệu vừa đọc.

Ví dụ nguồn 10003 byte có thể đọc theo ba khối 4096, 4096 và 1811. Chương trình chỉ ghi 1811 byte ở khối cuối, tránh dữ liệu dư. Nếu các lần đọc ngắn hơn, chương trình vẫn đọc tiếp đến khi nhận 0.

Partial write được xử lý bằng offset. Nếu yêu cầu 4096 nhưng write chỉ ghi 2000 byte thì lần kế tiếp bắt đầu từ buffer + 2000 và còn 2096 byte cần ghi.

## 5. Thuật toán sao chép thư mục

```text
COPY_PATH(src, dest)
    Kiểm tra src bằng lstat
    Nếu là folder:
        Cần chế độ recursive
        Chuẩn hóa đường dẫn, từ chối quan hệ nguồn/đích chồng lấn
        Tạo folder đích nếu thiếu
        Duyệt bằng opendir/readdir
        Bỏ qua . và ..
        Với mỗi mục: gọi xử lý tương ứng
        Đóng DIR
        Nếu bật preserve: đặt quyền/thời gian folder sau khi xử lý con
    Nếu là symlink:
        Đọc chuỗi liên kết bằng readlink
        Tạo liên kết tại đích bằng symlink
        Không duyệt nội dung link
    Nếu là regular file:
        Bỏ qua nếu chính sách skip và đích đã có
        Gọi copy_file_ex
    Các loại khác:
        Báo không hỗ trợ
```

Thư mục đích đã có được merge, không xóa file không liên quan. Thư mục rỗng vẫn được tạo. Link vòng không dẫn đến đệ quy vô hạn vì chương trình dùng lstat và sao chép liên kết thay vì đi theo nó.

## 6. Flags, tài nguyên và xử lý lỗi

Đích mở với O_WRONLY | O_CREAT | O_TRUNC, kèm O_NOFOLLOW. Quyền yêu cầu 0666 khi tạo file mới được điều chỉnh bởi umask. O_TRUNC loại nội dung cũ để đích dài hơn nguồn không giữ lại dữ liệu thừa.

Trước khi mở đích, chương trình kiểm tra st_dev và st_ino để tránh cắt chính nguồn qua hard link. Kiểm tra này có giới hạn TOCTOU; phiên bản yêu cầu đường dẫn ổn định trong thời gian sao chép và không được mô tả là an toàn trước tác nhân đồng thời thay đổi đường dẫn.

Descriptor được khởi tạo -1. Nhánh lỗi lưu errno rồi đóng các descriptor đã mở, sau đó khôi phục errno gốc. Đường thành công vẫn kiểm tra close vì lỗi I/O có thể báo muộn. Trên Linux không retry close dù EINTR vì descriptor có thể đã được giải phóng.

SIGINT chỉ đặt một cờ trong signal handler. Các vòng xử lý kiểm tra cờ và dừng hợp tác, giải phóng tài nguyên bên ngoài handler. File đích đang chép có thể còn dở.

## 7. Thiết kế giao diện Terminal

Menu gồm sao chép file, sao chép thư mục, xem trước, tạo dữ liệu mẫu, so sánh hai file, sao chép có bộ lọc, hướng dẫn và thoát. Chế độ xem trước chỉ liệt kê kế hoạch, không tạo/ghi/sửa metadata đích, không verify và không bảo đảm quyền hoặc dung lượng khi thực hiện thật. Sau khi chọn thao tác, người dùng nhập nguồn, đích, chính sách trùng tên và lựa chọn verify. Prompt kiểm tra lựa chọn không hợp lệ và cho phép thử lại.

ANSI cyan dùng cho tiêu đề và thanh tiến trình, xanh lá cho thành công, đỏ cho lỗi. Màu tự tắt khi stdout không phải TTY, TERM=dumb hoặc có NO_COLOR. Thanh tiến trình thể hiện phần trăm ghi của file hiện tại, không phải phần trăm toàn cây. Dấu OK sau khi đóng và verify thành công mới xác nhận file hoàn tất.

Bảng kết quả gồm file thành công, folder xử lý, symlink, bỏ qua, lỗi, byte regular file thành công, thời gian và tốc độ trung bình toàn tác vụ. Thời gian sử dụng CLOCK_MONOTONIC. Tốc độ có bao gồm verify khi bật nên không xem là benchmark ổ đĩa thuần.

## 8. Kiểm thử và kết quả

61 ca tích hợp đã đạt: 16 ca file cơ bản, 18 nhóm ca thư mục/giao diện, 9 ca dry-run/preserve và 18 ca filter/compare/demo/hướng dẫn đường dẫn. Các nhóm chính gồm file rỗng, kích thước biên 4096, file nhị phân, UTF-8, ghi đè, bỏ qua, cây nhiều cấp, folder rỗng, symlink, đường dẫn sai, overlap và hai luồng menu sao chép.

Fault test ép short read 13 byte, short write 3 byte và EINTR, sau đó kiểm tra nội dung đầy đủ. Test phát hiện byte thừa khi verify, xử lý cờ hủy và tham số NULL. Bốn mode lỗi ENOSPC, write trả 0, read EIO và close EIO chạy 100 lần mỗi mode. Không phát hiện tăng descriptor qua /proc/self/fd; mã lỗi đúng kỳ vọng.

Kiểm tra giao diện qua pseudo-terminal xác nhận ANSI màu, menu, thanh tiến trình và hoàn thành thao tác xuất hiện trong đầu ra. Đây là kiểm tra hành vi Terminal, không thay thế thử nghiệm trên mọi font và trình giả lập Terminal.

Có thể tái tạo kết quả bằng make test; bộ dự án không lưu log chạy và bản thu Terminal vào repository. Fault injection là giả lập lỗi có kiểm soát; không tuyên bố đã thử mất điện hoặc làm đầy ổ đĩa thật.

## 9. Đánh giá độ phức tạp

Với N byte dữ liệu file, copy có lượng dữ liệu I/O tuyến tính O(N), buffer dữ liệu O(4096). Verify đọc thêm nguồn và đích nên vẫn O(N), nhưng tăng khối lượng I/O. Trong điều kiện đọc/ghi đầy khối, số lần gọi hệ thống xấp xỉ tỷ lệ N/4096; short I/O có thể tăng số lần gọi.

Với M mục và độ sâu cây H, duyệt cây thực hiện theo số mục và lượng dữ liệu. Phần đệ quy cần tài nguyên theo độ sâu H, gồm stack, chuỗi đường dẫn và một DIR mở mỗi cấp. Cây quá sâu có thể chạm giới hạn tài nguyên.

## 10. Giới hạn và phát triển

Tùy chọn preserve giữ quyền rwx và atime/mtime của regular file và thư mục. Chương trình chưa sao chép ownership, ACL, xattr, bit quyền đặc biệt hoặc metadata symlink; không giữ sparse layout hoặc hard-link layout. Nguồn phải ổn định trong quá trình chạy. O_TRUNC xóa đích cũ trước khi hoàn tất, nên lỗi có thể để file dở và chưa có rollback. Không có fsync hoặc atomic replacement. Verify xác nhận nội dung đọc lại tại thời điểm kiểm tra, không bảo đảm an toàn trước mất điện.

Hướng phát triển có thể gồm ghi vào file tạm rồi rename, đồng bộ dữ liệu, giữ metadata, giới hạn tài nguyên cây và thiết kế chống thay đổi đường dẫn đồng thời. Các tính năng đó chưa được mô tả là có trong bản hiện tại.

## 11. Kịch bản demo trước lớp

1. Chạy make và mở ./filecopy để giới thiệu menu.
2. Chọn Preview để xem các file dự kiến trước khi ghi. Sau đó chọn sao chép file nhị phân, bật verify; quan sát thanh tiến trình và thống kê.
3. Chọn sao chép thư mục có hai cấp và folder rỗng.
4. Chép lại bằng skip để minh họa giữ đích đã tồn tại.
5. Dùng cmp kiểm tra file nhị phân và make test minh họa kiểm thử.
6. Thử đích nằm trong nguồn để thấy chương trình từ chối.

## 12. Bài nói ngắn

“Đề tài của em là xây dựng chương trình sao chép file và thư mục bằng C trên Linux. Phần chính sử dụng bốn hàm POSIX là open, read, write và close.

Em dùng buffer 4096 byte, chỉ ghi đúng số byte thực tế đã đọc. Nếu write chưa ghi hết, chương trình tiếp tục từ vị trí dữ liệu còn thiếu. Vì không xem nội dung là chuỗi nên chương trình sao chép được cả văn bản và file nhị phân.

Với thư mục, chương trình duyệt từng mục, tạo thư mục tương ứng và gọi hàm sao chép cho các file. Symbolic link được giữ nguyên và không được đi theo để tránh vòng lặp.

Em bổ sung menu có màu, thanh tiến trình file, lựa chọn ghi đè hoặc bỏ qua và kiểm tra dữ liệu sau sao chép. Phiên bản 4.0 có thêm xem trước không ghi dữ liệu và giữ quyền truy cập, thời gian của file và thư mục. Khi có lỗi hoặc Ctrl+C, chương trình đóng tài nguyên và thông báo kết quả.

Chương trình đã vượt qua 61 ca kiểm thử tích hợp cùng các ca giả lập lỗi đọc, ghi và đóng file. Phiên bản hiện tại vẫn có giới hạn: chưa bảo toàn đầy đủ metadata và khi lỗi có thể để lại file đích chép dở.”

## 13. Phần mở rộng phiên bản 4.0

Tạo dữ liệu mẫu giải quyết khó khăn khi người dùng chưa có file nguồn: chọn menu 5 sẽ tạo một thư mục riêng trong vị trí hiện tại, bên trong có văn bản, nhị phân, cây thư mục và đích sao chép. Thư mục dùng mkdtemp để tránh ghi đè mẫu cũ. Mẫu được giữ lại để thực hành tiếp.

Chức năng so sánh độc lập dùng verify_file_ex để đọc hai file có sẵn, không sao chép. Khác nội dung trả EBADMSG; các lỗi I/O khác giữ errno của hệ thống. Chức năng có cờ hủy hợp tác và không tự tạo file bị thiếu.

Bộ lọc dùng fnmatch của POSIX, so khớp basename ở mọi cấp. CLI nhận tối đa 16 mẫu; một mục khớp bất kỳ mẫu nào sẽ bị loại, nếu là folder thì không duyệt vào. Không xóa nội dung cũ của đích tương ứng. Bộ đếm loại trừ tách khỏi bỏ qua trùng tên.

Wizard kiểm tra nguồn và thư mục cha của đích trước khi chuyển sang bước tiếp theo, cho sửa ngay tại bước nhập. Hỗ trợ ~ và ~/ theo HOME trong menu, không thực thi câu lệnh shell. Gợi ý lỗi tiếng Việt giúp phân biệt đường dẫn thiếu, quyền truy cập, hết chỗ và xung đột loại.

Phần mở rộng vẫn giữ nguyên chữ ký copy_file và logic open/read/write/close với buffer 4096 byte. Không thay phần sao chép hệ thống bằng lệnh cp hay thư viện copy có sẵn.
